package software.bernie.geckolib.network.packet;

import javax.annotation.Nullable;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.network.AbstractPacket;
import software.bernie.geckolib.network.GeckoLibNetwork;
import software.bernie.geckolib.util.ClientUtils;

/**
 * Packet for syncing user-definable animations that can be triggered from the
 * server for {@link net.minecraft.block.entity.BlockEntity
 * BlockEntities}
 */
public class BlockEntityAnimTriggerPacket extends AbstractPacket {
    private final BlockPos BLOCK_POS;
    private final String CONTROLLER_NAME;
    private final String ANIM_NAME;

    public BlockEntityAnimTriggerPacket(BlockPos blockPos, @Nullable String controllerName, String animName) {
        this.BLOCK_POS = blockPos;
        this.CONTROLLER_NAME = controllerName == null ? "" : controllerName;
        this.ANIM_NAME = animName;
    }

    public PacketByteBuf encode() {
        PacketByteBuf buf = PacketByteBufs.create();

        buf.writeBlockPos(this.BLOCK_POS);
        buf.writeString(this.CONTROLLER_NAME);
        buf.writeString(this.ANIM_NAME);

        return buf;
    }

    @Override
    public Identifier getPacketID() {
        return GeckoLibNetwork.BLOCK_ENTITY_ANIM_TRIGGER_SYNC_PACKET_ID;
    }

    public static void receive(MinecraftClient client, ClientPlayNetworkHandler handler, PacketByteBuf buf, PacketSender responseSender) {
        final BlockPos BLOCK_POS = buf.readBlockPos();
        final String CONTROLLER_NAME = buf.readString();
        final String ANIM_NAME = buf.readString();

        client.execute(() -> runOnThread(BLOCK_POS, CONTROLLER_NAME, ANIM_NAME));
    }

    private static void runOnThread(BlockPos blockPos, String controllerName, String animName) {
        BlockEntity blockEntity = ClientUtils.getLevel().getBlockEntity(blockPos);

        if (blockEntity instanceof GeoBlockEntity getBlockEntity)
            getBlockEntity.triggerAnim(controllerName.isEmpty() ? null : controllerName, animName);
    }
}
