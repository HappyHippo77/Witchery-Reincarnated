package dev.felnull.specialmodelloader.impl.model;

import dev.felnull.specialmodelloader.api.model.ModelOption;
import net.minecraft.client.render.model.UnbakedModel;
import net.minecraft.client.render.model.json.JsonUnbakedModel;
import net.minecraft.client.texture.MissingSprite;
import net.minecraft.client.util.SpriteIdentifier;
import net.minecraft.screen.PlayerScreenHandler;

public abstract class SpecialBaseUnbakedModel implements UnbakedModel {
    protected static final SpriteIdentifier MISSING = new SpriteIdentifier(PlayerScreenHandler.BLOCK_ATLAS_TEXTURE, MissingSprite.getMissingSpriteId());
    private final ModelOption modelOption;

    protected SpecialBaseUnbakedModel(ModelOption modelOption) {
        this.modelOption = modelOption;
    }

    public ModelOption getModelOption() {
        return modelOption;
    }

    public SpriteIdentifier getParticleLocation() {
        if (modelOption.getParticle() != null)
            return new SpriteIdentifier(PlayerScreenHandler.BLOCK_ATLAS_TEXTURE, modelOption.getParticle());
        return MISSING;
    }

    public JsonUnbakedModel.GuiLight getGuiLight() {
        if (modelOption.getGuiLight() == null)
            return JsonUnbakedModel.GuiLight.BLOCK;
        return modelOption.getGuiLight();
    }
}
