package dev.felnull.specialmodelloader.impl.model;

import com.google.common.base.Suppliers;
import net.fabricmc.fabric.api.renderer.v1.mesh.Mesh;
import net.fabricmc.fabric.api.renderer.v1.model.ModelHelper;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.render.model.json.ModelTransformation;
import net.minecraft.client.texture.Sprite;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockRenderView;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;

public class SimpleMeshModel extends SpecialBaseModel {
    private final Mesh mesh;
    private final Supplier<List<BakedQuad>[]> quadCache;

    public SimpleMeshModel(boolean useAmbientOcclusion, boolean usesBlockLight, Sprite particleIcon, ModelTransformation transforms, Mesh mesh) {
        super(useAmbientOcclusion, usesBlockLight, particleIcon, transforms);
        this.mesh = mesh;
        this.quadCache = Suppliers.memoize(() -> ModelHelper.toQuadLists(mesh));
    }

    @Override
    public void emitBlockQuads(BlockRenderView blockView, BlockState state, BlockPos pos, Supplier<Random> randomSupplier, RenderContext context) {
        context.meshConsumer().accept(mesh);
    }

    @Override
    public void emitItemQuads(ItemStack stack, Supplier<Random> randomSupplier, RenderContext context) {
        context.meshConsumer().accept(mesh);
    }

    @Override
    public @NotNull List<BakedQuad> getQuads(@Nullable BlockState blockState, @Nullable Direction direction, Random randomSource) {
        return this.quadCache.get()[ModelHelper.toFaceIndex(direction)];
    }
}
