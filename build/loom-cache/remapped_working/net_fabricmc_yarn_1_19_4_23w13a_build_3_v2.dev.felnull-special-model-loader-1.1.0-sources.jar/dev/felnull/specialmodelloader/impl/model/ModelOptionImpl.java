package dev.felnull.specialmodelloader.impl.model;

import com.google.gson.JsonObject;
import dev.felnull.specialmodelloader.api.model.ModelOption;
import dev.felnull.specialmodelloader.impl.mixin.BlockModelAccessor;
import net.minecraft.client.render.model.json.JsonUnbakedModel;
import net.minecraft.client.render.model.json.ModelTransformation;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public record ModelOptionImpl(boolean useAmbientOcclusion, JsonUnbakedModel.GuiLight guiLight, Identifier particle,
                              ModelTransformation transforms) implements ModelOption {

    public static ModelOptionImpl parse(JsonObject modelJson) {
        ModelTransformation transform = ModelTransformation.NONE;

        if (modelJson.has("display")) {
            var jo = JsonHelper.getObject(modelJson, "display");
            transform = BlockModelAccessor.getGson().fromJson(jo, ModelTransformation.class);
        }

        JsonUnbakedModel.GuiLight guiLight = null;
        if (modelJson.has("gui_light"))
            guiLight = JsonUnbakedModel.GuiLight.byName(JsonHelper.getString(modelJson, "gui_light"));

        Identifier particle = null;
        if (modelJson.has("particle"))
            particle = new Identifier(JsonHelper.getString(modelJson, "particle"));

        return new ModelOptionImpl(JsonHelper.getBoolean(modelJson, "ambientocclusion", true), guiLight, particle, transform);
    }

    @Override
    public boolean isUseAmbientOcclusion() {
        return useAmbientOcclusion;
    }

    @Override
    public @Nullable JsonUnbakedModel.GuiLight getGuiLight() {
        return guiLight;
    }

    @Override
    public @Nullable Identifier getParticle() {
        return particle;
    }

    @Override
    public @NotNull ModelTransformation getTransforms() {
        return transforms;
    }
}
