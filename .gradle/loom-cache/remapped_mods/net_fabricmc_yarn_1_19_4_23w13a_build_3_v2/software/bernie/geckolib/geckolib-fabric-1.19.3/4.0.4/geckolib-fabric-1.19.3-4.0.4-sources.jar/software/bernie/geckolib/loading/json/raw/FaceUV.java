package software.bernie.geckolib.loading.json.raw;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import software.bernie.geckolib.util.JsonUtil;

import javax.annotation.Nullable;
import net.minecraft.util.JsonHelper;

/**
 * Container class for face UV information, only used in deserialization at startup
 */
public record FaceUV(@Nullable String materialInstance, double[] uv, double[] uvSize) {
	public static JsonDeserializer<FaceUV> deserializer() throws JsonParseException {
		return (json, type, context) -> {
			JsonObject obj = json.getAsJsonObject();
			String materialInstance = JsonHelper.getString(obj, "material_instance", null);
			double[] uv = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(obj, "uv", null));
			double[] uvSize = JsonUtil.jsonArrayToDoubleArray(JsonHelper.getArray(obj, "uv_size", null));

			return new FaceUV(materialInstance, uv, uvSize);
		};
	}
}
