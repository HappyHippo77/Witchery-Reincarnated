package dev.felnull.specialmodelloader.impl.util;

import com.google.gson.JsonObject;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;

public class JsonModelUtils {
    public static Identifier getParentLocation(JsonObject modelJson) {
        if (modelJson == null)
            return null;

        if (modelJson.has("parent"))
            return new Identifier(JsonHelper.getString(modelJson, "parent"));
        return null;
    }
}
