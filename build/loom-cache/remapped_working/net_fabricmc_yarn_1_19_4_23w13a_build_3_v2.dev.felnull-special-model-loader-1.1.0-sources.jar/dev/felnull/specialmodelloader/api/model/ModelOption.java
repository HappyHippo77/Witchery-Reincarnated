package dev.felnull.specialmodelloader.api.model;

import com.google.gson.JsonObject;
import dev.felnull.specialmodelloader.impl.model.ModelOptionImpl;
import net.minecraft.client.render.model.json.JsonUnbakedModel;
import net.minecraft.client.render.model.json.ModelTransformation;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface ModelOption {
    @NotNull
    static ModelOption of(boolean useAmbientOcclusion, @Nullable JsonUnbakedModel.GuiLight guiLight, @Nullable Identifier particle, @NotNull ModelTransformation transforms) {
        return new ModelOptionImpl(useAmbientOcclusion, guiLight, particle, transforms);
    }

    @NotNull
    static ModelOption parse(@NotNull JsonObject modelJson) {
        return ModelOptionImpl.parse(modelJson);
    }

    boolean isUseAmbientOcclusion();

    @Nullable
    JsonUnbakedModel.GuiLight getGuiLight();

    @Nullable
    Identifier getParticle();

    @NotNull
    ModelTransformation getTransforms();
}
