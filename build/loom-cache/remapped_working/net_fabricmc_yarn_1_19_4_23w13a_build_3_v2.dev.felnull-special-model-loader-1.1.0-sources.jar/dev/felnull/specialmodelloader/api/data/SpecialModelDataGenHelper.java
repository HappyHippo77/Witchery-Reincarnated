package dev.felnull.specialmodelloader.api.data;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.felnull.specialmodelloader.impl.SpecialModelLoader;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.block.Block;
import net.minecraft.data.client.ModelIds;
import net.minecraft.item.Item;
import net.minecraft.util.Identifier;

public final class SpecialModelDataGenHelper {
    private static final Identifier OBJ_LOADER = new Identifier(SpecialModelLoader.MODID, "builtin/obj");

    public static void generateObjModel(@NotNull Identifier location, @NotNull Identifier objLocation, boolean flipV, boolean useAmbientOcclusion, @Nullable Identifier particle, @NotNull BiConsumer<Identifier, Supplier<JsonElement>> output) {
        output.accept(location, () -> {
            var jo = new JsonObject();
            jo.addProperty("parent", OBJ_LOADER.toString());
            jo.addProperty("model", objLocation.toString());
            jo.addProperty("flip_v", flipV);
            jo.addProperty("ambientocclusion", useAmbientOcclusion);

            if (particle != null)
                jo.addProperty("particle", particle.toString());

            return jo;
        });
    }

    public static void generateObjModel(@NotNull Item item, @NotNull Identifier objLocation, boolean flipV, boolean useAmbientOcclusion, @Nullable Identifier particle, @NotNull BiConsumer<Identifier, Supplier<JsonElement>> output) {
        generateObjModel(ModelIds.getItemModelId(item), objLocation, flipV, useAmbientOcclusion, particle, output);
    }

    public static void generateObjModel(@NotNull Block block, @NotNull Identifier objLocation, boolean flipV, boolean useAmbientOcclusion, @Nullable Identifier particle, @NotNull BiConsumer<Identifier, Supplier<JsonElement>> output) {
        generateObjModel(ModelIds.getBlockModelId(block), objLocation, flipV, useAmbientOcclusion, particle, output);
    }
}