package software.bernie.example.registry;

import software.bernie.example.block.GeckoHabitatBlock;
import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import software.bernie.example.block.FertilizerBlock;
import software.bernie.geckolib.GeckoLib;

public class BlockRegistry {

    public static final GeckoHabitatBlock GECKO_HABITAT_BLOCK = registerBlock("gecko_habitat", new GeckoHabitatBlock());
    public static final FertilizerBlock FERTILIZER_BLOCK = registerBlock("fertilizer", new FertilizerBlock());

    public static <B extends Block> B registerBlock(String name, B block) {
        return register(block, new Identifier(GeckoLib.MOD_ID, name));
    }

    private static <B extends Block> B register(B block, Identifier name) {
        Registry.register(Registries.BLOCK, name, block);
        BlockItem item = new BlockItem(block, (new Item.Settings()));

        item.appendBlocks(Item.BLOCK_ITEMS, item);
        Registry.register(Registries.ITEM, name, item);
        return block;
    }
}
