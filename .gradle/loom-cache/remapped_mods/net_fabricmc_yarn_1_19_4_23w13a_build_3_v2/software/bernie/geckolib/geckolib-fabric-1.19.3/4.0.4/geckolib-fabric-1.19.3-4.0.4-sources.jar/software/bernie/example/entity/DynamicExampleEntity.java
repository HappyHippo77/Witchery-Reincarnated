package software.bernie.example.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.RangedWeaponItem;
import net.minecraft.item.ShieldItem;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;
import net.minecraft.world.item.*;
import software.bernie.example.client.renderer.entity.MutantZombieRenderer;
import software.bernie.geckolib.GeckoLib;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.constant.DefaultAnimations;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.renderer.DynamicGeoEntityRenderer;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Example extended-support entity for GeckoLib advanced rendering
 * @see DynamicGeoEntityRenderer
 * @see MutantZombieRenderer
 * @see software.bernie.example.client.renderer.entity.GremlinRenderer
 */
public class DynamicExampleEntity extends PathAwareEntity implements GeoEntity {
	// Pre-define our RawAnimations for use later
	private static final RawAnimation BLOCK_LEFT = RawAnimation.begin().thenPlay("attack.block.left");
	private static final RawAnimation BLOCK_RIGHT = RawAnimation.begin().thenPlay("attack.block.right");
	private static final RawAnimation AIM_LEFT_HAND = RawAnimation.begin().thenPlay("pose.aim.left");
	private static final RawAnimation AIM_RIGHT_HAND = RawAnimation.begin().thenPlay("pose.aim.right");
	private static final RawAnimation SPEAR_LEFT_HAND = RawAnimation.begin().thenPlay("pose.spear.left");
	private static final RawAnimation SPEAR_RIGHT_HAND = RawAnimation.begin().thenPlay("pose.spear.right");
	private static final RawAnimation INTERACT_LEFT = RawAnimation.begin().thenPlay("misc.interact.right");
	private static final RawAnimation INTERACT_RIGHT = RawAnimation.begin().thenPlay("misc.interact.right");
	private static final RawAnimation SPEAR_SWING = RawAnimation.begin().thenPlay("attack.spear");

	private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

	public DynamicExampleEntity(EntityType<? extends PathAwareEntity> entityType, World level) {
		super(entityType, level);
	}

	@Override
	protected void initGoals() {
		this.goalSelector.add(0, new LookAtEntityGoal(this, PlayerEntity.class, 8));
	}

	// Let's add our animation controllers
	@Override
	public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
		controllers.add(
				DefaultAnimations.genericIdleController(this),
				new AnimationController<>(this, "Body", 20, this::poseBody),
				new AnimationController<>(this, "Left Hand", 10, state -> predicateHandPose(getLeftHand(), state))
						.triggerableAnim("interact", INTERACT_LEFT),
				new AnimationController<>(this, "Right Hand", 10, state -> predicateHandPose(getRightHand(), state))
						.triggerableAnim("interact", INTERACT_RIGHT),
				new AnimationController<>(this, "Dual Wield Pose", 10, this::poseDualWield),
				new AnimationController<>(this, "Dual Wield Attack", 10, this::attackDualWield)
		);
	}

	// Create the animation handler for the body segment
	protected PlayState poseBody(AnimationState<DynamicExampleEntity> state) {
		if (isWieldingTwoHandedWeapon())
			return PlayState.STOP;

		if (hasVehicle()) {
			state.setAnimation(DefaultAnimations.SIT);
		}
		else if (isInSneakingPose()) {
			state.setAnimation(DefaultAnimations.SNEAK);
		}

		return PlayState.CONTINUE;
	}

	// Create the animation handler for each hand
	protected PlayState predicateHandPose(Hand hand, AnimationState<DynamicExampleEntity> state) {
		ItemStack heldStack = getStackInHand(hand);

		if (heldStack.isEmpty() || isWieldingTwoHandedWeapon())
			return PlayState.STOP;

		Item handItem = heldStack.getItem();

		if (isBlocking() && (handItem instanceof ShieldItem || handItem.getUseAction(heldStack) == UseAction.BLOCK))
			return state.setAndContinue(getLeftHand() == hand ? BLOCK_LEFT : BLOCK_RIGHT);

		return PlayState.STOP;
	}

	// Create the animation handler for posing with a dual-wielded weapon
	private  PlayState poseDualWield(AnimationState<DynamicExampleEntity> state) {
		if (!isWieldingTwoHandedWeapon())
			return PlayState.STOP;

		for (ItemStack heldStack : getHandItems()) {
			UseAction useAnim = heldStack.getItem().getUseAction(heldStack);

			if (useAnim == UseAction.BOW || useAnim == UseAction.CROSSBOW) {
				return state.setAndContinue(isLeftHanded() ? AIM_LEFT_HAND : AIM_RIGHT_HAND);
			}
			else if (useAnim == UseAction.SPEAR) {
				return state.setAndContinue(isLeftHanded() ? SPEAR_LEFT_HAND : SPEAR_RIGHT_HAND);
			}
		}

		return PlayState.STOP;
	}

	// Create the animation handler for attacking with a dual-wielded weapon
	private <E extends GeoAnimatable> PlayState attackDualWield(AnimationState<E> state) {
		if (!this.handSwinging || !isWieldingTwoHandedWeapon())
			return PlayState.STOP;

		for (ItemStack heldStack : getHandItems()) {
			if (heldStack.getItem().getUseAction(heldStack) == UseAction.SPEAR)
				return state.setAndContinue(SPEAR_SWING);
		}

		return PlayState.STOP;
	}

	// Helper method to determine whether the entity should be considered to be dual-wielding or not
	public boolean isWieldingTwoHandedWeapon() {
		ItemStack mainHandStack = getMainHandStack();
		ItemStack offhandStack = getOffHandStack();

		if (mainHandStack.getItem() instanceof RangedWeaponItem ||
				offhandStack.getItem() instanceof RangedWeaponItem)
			return true;

		UseAction anim = mainHandStack.getUseAction();

		if (anim == UseAction.BOW || anim == UseAction.CROSSBOW || anim == UseAction.SPEAR)
			return true;

		anim = offhandStack.getUseAction();

		return anim == UseAction.BOW || anim == UseAction.CROSSBOW || anim == UseAction.SPEAR;
	}

	// Helper method to get the left hand in an ambidextrous entity
	protected Hand getLeftHand() {
		return this.isLeftHanded() ? Hand.MAIN_HAND : Hand.OFF_HAND;
	}

	// Helper method to get the right hand in an ambidextrous entity
	protected Hand getRightHand() {
		return !this.isLeftHanded() ? Hand.MAIN_HAND : Hand.OFF_HAND;
	}

	// Add a functionality to give the entity whatever we're holding when we click on it
	@Override
	protected ActionResult interactMob(PlayerEntity player, Hand hand) {
		ItemStack stack = player.getStackInHand(hand);

		if (this.world.isClient() || stack.isEmpty())
			return super.interactMob(player, hand);

		EquipmentSlot slot = LivingEntity.getPreferredEquipmentSlot(stack);

		equipStack(slot, stack.copy());
		player.sendMessage(Text.translatable("entity." + GeckoLib.MOD_ID + ".mutant_zombie.equip", stack.toHoverableText()));

		if (slot == EquipmentSlot.MAINHAND || slot == EquipmentSlot.OFFHAND)
			triggerAnim(getLeftHand() == hand ? "Left Hand" : "Right Hand", "interact");

		return ActionResult.SUCCESS;
	}

	@Override
	public AnimatableInstanceCache getAnimatableInstanceCache() {
		return this.cache;
	}
}