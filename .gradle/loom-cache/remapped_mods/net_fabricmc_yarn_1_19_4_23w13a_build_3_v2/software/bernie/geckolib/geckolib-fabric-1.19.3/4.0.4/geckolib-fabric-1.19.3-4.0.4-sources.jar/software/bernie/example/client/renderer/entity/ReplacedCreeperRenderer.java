package software.bernie.example.client.renderer.entity;

import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.util.math.MathHelper;
import software.bernie.example.client.model.entity.ReplacedCreeperModel;
import software.bernie.example.entity.ReplacedCreeperEntity;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoReplacedEntityRenderer;

/**
 * Example replacement renderer for a {@link CreeperEntity}.<br>
 * This functionally replaces the model and animations of an existing entity without needing to replace the entity entirely
 * @see GeoReplacedEntityRenderer
 * @see ReplacedCreeperEntity
 */
public class ReplacedCreeperRenderer extends GeoReplacedEntityRenderer<CreeperEntity, ReplacedCreeperEntity> {
	public ReplacedCreeperRenderer(EntityRendererFactory.Context renderManager) {
		super(renderManager, new ReplacedCreeperModel(), new ReplacedCreeperEntity());
	}

	@Override
	public void preRender(MatrixStack poseStack, ReplacedCreeperEntity animatable, BakedGeoModel model, VertexConsumerProvider bufferSource, VertexConsumer buffer, boolean isReRender, float partialTick, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		super.preRender(poseStack, animatable, model, bufferSource, buffer, isReRender, partialTick, packedLight, packedOverlay, red, green, blue, alpha);

		float swellFactor = this.currentEntity.getClientFuseTime(partialTick);
		float swellMod = 1 + MathHelper.sin(swellFactor * 100f) * swellFactor * 0.01f;
		swellFactor = (float)Math.pow(MathHelper.clamp(swellFactor, 0f, 1f), 3);
		float horizontalSwell = (1 + swellFactor * 0.4f) * swellMod;
		float verticalSwell = (1 + swellFactor * 0.1f) / swellMod;

		poseStack.scale(horizontalSwell, verticalSwell, horizontalSwell);
	}

	@Override
	public int getPackedOverlay(ReplacedCreeperEntity animatable, float u) {
		return super.getPackedOverlay(animatable, getSwellOverlay(this.currentEntity, u));
	}

	protected float getSwellOverlay(CreeperEntity entity, float u) {
		float swell = entity.getClientFuseTime(u);

		return (int) (swell * 10.0F) % 2 == 0 ? 0.0F : MathHelper.clamp(swell, 0.5F, 1.0F);
	}
}
