package dev.felnull.specialmodelloader.impl.model;

import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.json.ModelOverrideList;
import net.minecraft.client.render.model.json.ModelTransformation;
import net.minecraft.client.texture.Sprite;

public abstract class SpecialBaseModel implements BakedModel, FabricBakedModel {
    private final boolean useAmbientOcclusion;
    private final boolean usesBlockLight;
    private final Sprite particleIcon;
    private final ModelTransformation transforms;

    protected SpecialBaseModel(boolean useAmbientOcclusion, boolean usesBlockLight, Sprite particleIcon, ModelTransformation transforms) {
        this.useAmbientOcclusion = useAmbientOcclusion;
        this.usesBlockLight = usesBlockLight;
        this.particleIcon = particleIcon;
        this.transforms = transforms;
    }

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    @Override
    public boolean isBuiltin() {
        return false;
    }

    @Override
    public boolean useAmbientOcclusion() {
        return useAmbientOcclusion;
    }

    @Override
    public boolean hasDepth() {
        return true;
    }

    @Override
    public boolean isSideLit() {
        return usesBlockLight;
    }

    @Override
    public Sprite getParticleSprite() {
        return particleIcon;
    }

    @Override
    public ModelTransformation getTransformation() {
        return transforms;
    }

    @Override
    public ModelOverrideList getOverrides() {
        return ModelOverrideList.EMPTY;
    }
}
